﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionary
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> dict = new Dictionary<string, string>();

            //var dictState = new Dictionary<string, string>(); 
            //creates a dictionary that holds string key and string values.

            //add func for adding key value pairs
            dict.Add("1", "C#");
            dict.Add("2", "Python");
            dict.Add("3", "Java");
            dict.Add("4", ".net");
            // dict.Add("4", "njn");//exception-same key has already been used
            dict.Add("6", ".net");//value can be same

            dict["4"] = "HTML";

            dict.Add("","");//null both

            Console.WriteLine($"Total key/value pairs are :  { dict.Count}");

            //access all key value pairs
           // foreach (string key in dict.Keys)
             //   Console.WriteLine(key);
             foreach(string value in dict.Values)
            {
                Console.WriteLine(value);
            }

            foreach(KeyValuePair<string, string> kvp in dict)
            {
                Console.WriteLine($"Key  : {kvp.Key}, Value: {kvp.Value}");

            }

            //access items
            //dict['keyname']
            Console.WriteLine($"Value with key : 2 , {dict["2"]}");

        }
    }
}
